$(function(){
    if($('#rent').is(':checked')){
        $(".rent_charges").removeClass('d-none');
        $('.rent_charges').show();
    }else{
        $(".rent_charges").addClass('d-none');
        $('.rent_charges').hide();
    }
    
    $('#rent').click(function(){
        if ($(this).is(':checked')){
            $(".rent_charges").removeClass('d-none');
            $('.rent_charges').show();
        }else{
            $(".rent_charges").addClass('d-none');
            $('.rent_charges').hide();
        }
    });
});