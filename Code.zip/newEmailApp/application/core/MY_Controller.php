<?php
class MY_Controller extends CI_Controller
{
    public $user;
    public function __construct()
	{
        parent::__construct();
        date_default_timezone_set("Asia/Karachi");
        $this->getUserData();
	}

    public function login_check()
	{
		if (!$this->user) {
			$this->session->set_flashdata('msg','<div class="alert alert-danger text-center">Please Login First !</div>');
			redirect('account/login', 'refresh');
		}
	}

    public function userLoginCheck(){
        $this->login_check();
    }

    public function not_login_check()
	{
		if ($this->user) {
			redirect('inbox');
		}
	}

    public function getUserData()
	{
		if ($this->session->loginId) {
            $result = $this->login_model->get_record(['loginId' => decode($this->session->loginId), 'isLogout' => 0]);
            if ($result) {
                $this->user = $this->user_model->get_record(['id' => $result->userId]);
                $this->user = ($this->user && $this->user->is_active) ? $this->user : '';
            } else {
                $this->session->unset_userdata(array('loginId', 'userId'));
                $this->user = '';
            }
        } else
            $this->user = '';
	}

    public function send_api_response($status,$message = null, $res = array())
	{
		if ($this->mobile_api_check()) {
			if ($res) {
				$res['status'] = $status;
				$res['message'] = $message;
			} else{
				$res = array('status' => $status, 'message' => $message);
            }
			echo json_encode($res);die();
		}
	}

    public function slim_image_upload($image, $path, $if_not_set_image)
    {
        $this->load->library('slim');
        $image_error = FALSE;
        $image_path = array();
        $image = str_replace(' ','-',$image);
        try {
            $images = Slim::getImages($image);
        } catch (Exception $e) {
            Slim::outputJSON(array(
                'status' => SlimStatus::FAILURE,
                'message' => 'Unknown Error'
            ));
        }
        $image = array_shift($images);
        if ($images == FALSE) {
            $response['message'] = "The image field is required";
        } elseif (!isset($image)) {
            $response['message'] = "The image not found";
        } elseif (!isset($image['output']['data']) && !isset($image['input']['data'])) {
            $response['message'] = "The image field not send any data";
        }
        if (isset($image['output']['data'])) {
            $name = $image['output']['name'];
            $data = $image['output']['data'];
            $output = Slim::saveFile($data, $name, $path);
        }
        if (isset($image['input']['data'])) {
            $name = $image['input']['name'];
            $data = $image['input']['data'];
            $input = Slim::saveFile($data, $name, $path);
        }
        if (isset($output) && isset($input)) {
            $response['output'] = array(
                'file' => $output['name'],
                'path' => $image_path[0]
            );
            $response['input'] = array(
                'file' => $input['name'],
                'path' => $input['path']
            );
        }
        if (isset($output)) {
            $image_path = explode('./', $output['path']);
            $path = $image_path[1];
        } else {
            $image_path = explode('./', $path);
            $path = $image_path[1] . $if_not_set_image;
        }

        $response['file'] = isset($output) ? $output['name'] : $if_not_set_image;
        $response['path'] = $path;
        $response['status'] = isset($output) ? SlimStatus::SUCCESS : SlimStatus::FAILURE;
        // print_r($response);
        // die;
        return $response;
    }

    public function dd($data = null){
        echo "<pre>";print_r($data);echo "</pre>";die;
    }
}