<?php
defined('BASEPATH') or exit('No direct script access allowed');
class Home extends MY_Controller
{

    public function __construct(){
        parent::__construct();
        $this->userLoginCheck();
    }

    public function index()
    {
        $all_mails = array();
        $my_mails_with_replys = $this->mails_model->get_records(['author_id'=>$this->user->id,'replied'=>1],'desc');
        if($my_mails_with_replys){
            foreach ($my_mails_with_replys as $mail) {
                $msg = $this->mail_messages->get_record(['mail_id'=>$mail->id],'desc');
                if($msg){
                    $mail->last_msg_time = $msg->created_at;
                    $mail->msg = $msg;
                }
            }
        }

        $mail_from_others = $this->mail_to_model->get_inbox_mails($this->user->email);
        if($mail_from_others){
            foreach ($mail_from_others as $mail_other) {
                $msg1 = $this->mail_messages->get_record(['mail_id'=>$mail_other->id],'desc');
                if($msg1){
                    $mail_other->last_msg_time = $msg1->created_at;
                    $mail_other->msg = $msg1;
                }
            }
        }

        $all_mails = array_merge($my_mails_with_replys,$mail_from_others);        
        if($all_mails){
            array_multisort( array_column($all_mails, "last_msg_time"), SORT_DESC, $all_mails);
        }

        $data['mails'] = $all_mails;
        $data['title'] = SITE_NAME;
        $data['main_view'] = "home";
        $this->load->view('layout', $data);
    }

    public function compose()
    {
        $data['title'] = 'Compose Email';
        $this->form_validation->set_rules('to[]', 'To', 'trim|required');
        $this->form_validation->set_rules('cc[]', 'Cc', 'trim');
        $this->form_validation->set_rules('subject', 'Subject', 'trim|required');
        $this->form_validation->set_rules('body', 'Body', 'trim');
        if ($this->form_validation->run() == FALSE) {
            $data['main_view'] = "compose";
            $this->load->view('layout', $data);
        } else {
            $mailRecord = array(
                'author_id' => $this->user->id,
                'subject' => $this->input->post('subject'),
                'body' => $this->input->post('body') ? $this->input->post('body') : NULL,
            );
            $mail_id = $this->mails_model->insert_record($mailRecord);
            if($mail_id){
                $mail_to_array = array();
                if(isset($_POST['to']) && !empty($_POST['to'])){
                    foreach ($_POST['to'] as $to) {
                        $mail_to_array[] = array(
                            'mail_id' => $mail_id,
                            'email' => $to,
                            'type' => 'to',
                        );
                    }                    
                }
                $mail_cc_array = array();
                if(isset($_POST['cc']) && !empty($_POST['cc'])){
                    foreach ($_POST['cc'] as $cc) {
                        $mail_cc_array[] = array(
                            'mail_id' => $mail_id,
                            'email' => $cc,
                            'type' => 'cc'
                        );
                    }
                }
                $send_to_array = array_merge($mail_to_array,$mail_cc_array);
                $this->mail_to_model->insert_batch_record($send_to_array);

                $mailMsgRecord = array(
                    'mail_id' => $mail_id,
                    'msg_from' => $this->user->email,
                    'msg' => $this->input->post('body'),
                );
                $this->mail_messages->insert_record($mailMsgRecord);

                $this->session->set_flashdata('msg','<div class="alert alert-success text-center">Email Sent Successfully.</div>');
                redirect('/');
            
            }else{
                $this->session->set_flashdata('msg','<div class="alert alert-danger text-center">Error! Something went wrong. Email not sent.</div>');
                redirect('/');
            }
        }
    }

    public function sent()
    {
        $mails = array();
        $sent_mails = $this->mail_messages->get_sent_messages_mails($this->user->email);
        if($sent_mails){
            foreach ($sent_mails as $mail) {
                $mails[] = $this->mails_model->get_record(['mails.id'=>$mail->mail_id]);
            }
        }
        if($mails){
            foreach ($mails as $mail_other) {
                $msg1 = $this->mail_messages->get_record(['mail_id'=>$mail_other->id],'desc');
                if($msg1){
                    $mail_other->last_msg_time = $msg1->created_at;
                    $mail_other->msg = $msg1;
                }
            }
        }
        if($mails){
            array_multisort( array_column($mails, "last_msg_time"), SORT_DESC, $mails);
        }

        $data['mails'] = $mails;
        $data['title'] = 'Sent';
        $data['main_view'] = "sent";
        $this->load->view('layout', $data);
    }

    public function detail($id)
    {
        $mail_record = $this->mails_model->get_record(['mails.id'=>$id]);
        if($mail_record){            
            if(isset($_POST) && !empty($_POST) && isset($_POST['reply']) && !empty($_POST['reply'])){
                $mailMsgRecord = array(
                    'mail_id' => $id,
                    'msg_from' => $this->user->email,
                    'msg' => $this->input->post('reply')
                );
                $this->mail_messages->insert_record($mailMsgRecord);
                $this->mails_model->update_record(['id'=>$id],['replied'=>1]);
            }
            $data['mail_to'] = $this->mail_to_model->get_mail_to_emails($id);
            $data['mail_cc'] = $this->mail_to_model->get_mail_cc_emails($id);
            $data['detail'] = $mail_record;
            $data['childs'] = $this->mail_messages->get_records(['mail_messages.mail_id'=>$id],'asc');
            $data['form_action'] = base_url().'detail/'.$id;
            $data['title'] = 'Detail';
            $data['main_view'] = "detail";
            $this->load->view('layout', $data);
        }else{
            redirect('inbox');
        }
    }
}