<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Account extends MY_Controller {

    function __construct(){
		parent::__construct();
	}

    public function index(){
        redirect('/');
    }

    // This function will check if email exist than check password and give results
    // If email not exists user will registered and login
    public function login(){
        $this->not_login_check();
        $this->form_validation->set_rules('name', 'Name', 'trim');
        $this->form_validation->set_rules('email', 'Email', 'trim|required');
        $this->form_validation->set_rules('password', 'Password', 'trim|required');
        if ($this->form_validation->run() == FALSE) {
            $this->load->view('login');
        } else {
            $user = $this->user_model->get_record(['email' => $this->input->post('email')]);
            if($user!=NULL){
                $password = password_verify($this->input->post('password'),$user->password);
                if($password){
                    // if password matches than i am entering user record in login table and table id make encode and stored in session 
                    $this->login_model->update_record(['userId' => $user->id],['isLogout' => 0]);
                    $loginId = $this->login_model->insert_record(['userId' => $user->id,'loginDevice' => 'web']);
                    $this->session->set_userdata('userId',encode($user->id));
                    $this->session->set_userdata('loginId',encode($loginId));
                    redirect('inbox');
                }else{
                    $this->session->set_flashdata('msg','<div class="alert alert-danger text-center">Incorrect Password !</div>');
                    redirect('account/login');
                }
            }else{
                $userData = array(
                    'name' => $this->input->post('name') ? $this->input->post('name') : 'Anonymous',
                    'email' => $this->input->post('email'),
                    'password' => password_hash($this->input->post('password'),PASSWORD_DEFAULT)
                );
                $id = $this->user_model->insert_record($userData);
                if($id){
                    //after user creating i am entering user record in login table and table id make encode and stored in session 
                    $loginId = $this->login_model->insert_record(['userId' => $id,'loginDevice' => 'web']);
                    $this->session->set_userdata('userId',encode($id));
                    $this->session->set_userdata('loginId',encode($loginId));
                    redirect('inbox');
                }
            }
        }        
    }

    public function logout(){
        if ($this->user) {
			$loginId = decode($this->session->loginId);
			$this->login_model->update_record(array('loginId' => $loginId), array('isLogout' => 1));
		}
        $this->session->unset_userdata(array('userId', 'loginId'));
        redirect('account/login', 'refresh');
    }
}
