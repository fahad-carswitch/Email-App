<?php $this->load->view('common/header') ?>
<?php $this->load->view($main_view) ?>
<?php $this->load->view('common/footer') ?>