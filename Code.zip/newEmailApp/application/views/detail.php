<div class="page-wrapper">
    <div class="container-fluid">
        <div class="row">
            <?php if($this->session->flashdata('msg')){?><div class="col-md-12"><?php echo $this->session->flashdata('msg'); ?></div><?php } ?>
            <div class="col-lg-12">
                <div class="card">
                    <div class="row">
                        <?php $this->load->view('common/sidebar') ?>
                        <div class="col-xlg-10 col-lg-9 col-md-8 bg-light border-left">    
                            <div class="card-body p-t-0">
                                <div class="card b-all shadow-none">
                                    <div class="card-body">
                                        <h3 class="card-title m-b-0"><?= $detail->subject ?></h3>
                                    </div>
                                    <div>
                                        <hr class="m-t-0">
                                    </div>
                                    <div class="card-body">
                                        <div class="d-flex m-b-20">
                                            <div>
                                                <a href="javascript:void(0)"><img src="<?= base_url() ?>assets/images/user.png" alt="user" width="40" class="img-circle" /></a>
                                            </div>
                                            <div class="p-l-10">
                                                <h4 class="m-b-0"><?= $detail->authorName ? $detail->authorName : 'Anonymous' ?></h4>
                                                <small class="text-muted">From : <?= $detail->authorEmail ?></small><br>
                                                <small class="text-muted">To : <?= $mail_to->emails_to ?></small>
                                                <?php if($mail_cc->email_cc){ ?>
                                                    <br><small class="text-muted">Cc : <?= $mail_cc->email_cc ?></small>
                                                <?php } ?>
                                            </div>
                                        </div>
                                        <p><?= $detail->body; ?></p>
                                    </div>
                                    <div><hr class="m-t-0"></div>
                                    <?php if(isset($childs) & !empty($childs)){
                                        foreach ($childs as $mail) { ?>
                                            <div class="card-body">
                                                <div class="d-flex m-b-20">
                                                    <div>
                                                        <a href="javascript:void(0)"><img src="<?= base_url() ?>assets/images/user.png" alt="user" width="40" class="img-circle" /></a>
                                                    </div>
                                                    <div class="p-l-10">
                                                        <h4 class="m-b-0"><?= $mail->senderName ? $mail->senderName : 'Anonymous' ?></h4>
                                                        <small class="text-muted">From: <?= $mail->senderEmail ?></small>
                                                    </div>
                                                </div>
                                                <p><?= $mail->msg; ?></p>
                                            </div>
                                            <div><hr class="m-t-0"></div>
                                        <?php }
                                    } ?>
                                    <div class="card-body">
                                        <div class="b-all m-t-20">
                                            <p class="p-b-20">click here to <a id="replyBtn" href="javascript:void(0)">Reply</a></p>
                                        </div>
                                        <form action="<?= $form_action; ?>" method="post" id="replyForm" class="replyForm d-none">
                                            <div class="form-group">
                                                <textarea name="reply" placeholder="Enter Reply" class="form-control" id="reply" cols="30" rows="7"></textarea>
                                            </div>
                                            <!-- <input type="hidden" name="send_to" value="<?php // echo $detail->senderEmail ?>"> -->
                                            <div class="form-group">
                                                <input type="submit" class="btn btn-success" value="Send">
                                                <button class="btn btn-primary" type="button" id="cancelReply">Cancel</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<script>
    $("#replyBtn").click(function () {
        $("#replyForm").removeClass('d-none');
    });
    $("#cancelReply").click(function () {
        $("#replyForm").addClass('d-none');
    });
    
</script>