<style>
    .bootstrap-tagsinput{
        width:100% !important;
    }
</style>
<div class="page-wrapper">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="row">
                        <?php $this->load->view('common/sidebar') ?>
                        <div class="col-xlg-10 col-lg-9 col-md-8 bg-light border-left">
                            <div class="card-body">
                                <form action="" method="post">
                                    <h3 class="card-title">Compose New Message</h3>
                                    <div class="form-group">
                                        <label for="to">To</label>
                                        <select multiple name="to[]" id="to" class="form-control"  data-role="tagsinput"></select>
                                        <?php echo form_error('to[]','<span class="text-danger">','</span>'); ?>
                                    </div>
                                    <div class="form-group">
                                        <label for="cc">Cc</label>
                                        <select multiple name="cc[]" id="cc" class="form-control" data-role="tagsinput"></select>
                                        <?php echo form_error('cc[]','<span class="text-danger">','</span>'); ?>    
                                    </div>

                                    <div class="form-group">
                                        <label for="Subject">Subject</label>
                                        <input class="form-control" name="subject" value="<?=set_value('subject')?>" required>
                                        <?php echo form_error('subject','<span class="text-danger">','</span>'); ?>
                                    </div>
                                    <div class="form-group">
                                        <label for="Message">Message</label>
                                        <textarea class="form-control" name="body" rows="10"><?=set_value('body')?></textarea>
                                        <?php echo form_error('body','<span class="text-danger">','</span>'); ?>    
                                    </div>
                                    <button type="submit" class="btn btn-success m-t-20"><i class="fa fa-envelope-o"></i> Send</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>