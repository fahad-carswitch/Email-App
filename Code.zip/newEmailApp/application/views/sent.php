<style>
    .threads a{
        color:#333;
    }
</style>
<div class="page-wrapper">
    <div class="container-fluid">
        <div class="row">
            <?php if($this->session->flashdata('msg')){?><div class="col-md-12"><?php echo $this->session->flashdata('msg'); ?></div><?php } ?>
            <div class="col-lg-12">
                <div class="card">
                    <div class="row">
                        <?php $this->load->view('common/sidebar') ?>
                        <div class="col-lg-9 col-md-8 bg-light border-left" style="height:100vh !important;">
                            <div class="card-body p-t-0">
                                <h3 class="card-title" style="margin-top:10px;">Sent</h3>
                                <div class="card b-all shadow-none threads" style="padding:15px;">
                                    <?php if(isset($mails) && !empty($mails)){
                                        foreach ($mails as $mail) { ?>
                                            <div class="d-flex" style="align-items: center; width:100%; height:50px;">
                                                <div style="width:15%;overflow:hidden;">
                                                    <?php if($mail->msg->senderId == $this->user->id){
                                                        echo "Me";
                                                    }else{ echo $mail->msg->senderName; } ?>
                                                </div>
                                                <div style="width:35%;overflow:hidden; height:20px;">
                                                    <a href="<?= base_url() ?>detail/<?= $mail->id ?>"><?= $mail->subject ? $mail->subject : 'N/A' ?></a>
                                                </div>
                                                <div style="width:35%;overflow:hidden; height:20px;">
                                                    <a href="<?= base_url() ?>detail/<?= $mail->id ?>"> <?= $mail->msg->msg ? $mail->msg->msg : $mail->body ?></a>
                                                </div>
                                                <?php if(date('Y',strtotime($mail->last_msg_time)) == date('Y')){
                                                    $mail_date = date('d-M h:i A',strtotime($mail->last_msg_time));
                                                }else{
                                                    $mail_date = date('d-M-Y h:i A',strtotime($mail->last_msg_time));
                                                } ?>
                                                <div style="width:15%;overflow:hidden;"><?= $mail_date ?></div>
                                            </div>
                                        <?php }
                                    }else{ ?>
                                    <div class="d-flex" style="justify-content: center;align-items: center;">
                                        <img src="<?= base_url() ?>assets/images/no-spam.png" style="width:150px;margin-top:30px;margin-bottom:30px;" alt="">
                                    </div>
                                    <?php } ?>



                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>