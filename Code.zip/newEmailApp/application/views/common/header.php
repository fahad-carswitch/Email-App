<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Email App">
    <meta name="author" content="Ali Sher">
    <title>Email App</title>
    <link href="<?= base_url() ?>assets/dist/css/style.min.css" rel="stylesheet">
    <link href="<?= base_url() ?>assets/dist/css/pages/inbox.css" rel="stylesheet">

    <link href="<?= base_url() ?>assets/node_modules/bootstrap-datepicker/bootstrap-datepicker.min.css" rel="stylesheet" type="text/css" />
    <link href="<?= base_url() ?>assets/node_modules/select2/dist/css/select2.min.css" rel="stylesheet" type="text/css" />
    <link href="<?= base_url() ?>assets/node_modules/switchery/dist/switchery.min.css" rel="stylesheet" />
    <link href="<?= base_url() ?>assets/node_modules/bootstrap-select/bootstrap-select.min.css" rel="stylesheet" />
    <link href="<?= base_url() ?>assets/node_modules/bootstrap-tagsinput/dist/bootstrap-tagsinput.css" rel="stylesheet" />
    <link href="<?= base_url() ?>assets/node_modules/bootstrap-touchspin/dist/jquery.bootstrap-touchspin.min.css" rel="stylesheet" />
    <link href="<?= base_url() ?>assets/node_modules/multiselect/css/multi-select.css" rel="stylesheet" type="text/css" />
    <script src="<?= base_url() ?>assets/node_modules/jquery/jquery-3.2.1.min.js"></script>
</head>

<body class="horizontal-nav skin-megna fixed-layout">
    <div class="preloader">
        <div class="loader">
            <div class="loader__figure"></div>
            <p class="loader__label">Email App</p>
        </div>
    </div>
    <div id="main-wrapper">