</div>
    <script src="<?= base_url() ?>assets/node_modules/popper/popper.min.js"></script>
    <script src="<?= base_url() ?>assets/node_modules/bootstrap/dist/js/bootstrap.min.js"></script>
    <script src="<?= base_url() ?>assets/dist/js/perfect-scrollbar.jquery.min.js"></script>
    <script src="<?= base_url() ?>assets/dist/js/waves.js"></script>
    <script src="<?= base_url() ?>assets/dist/js/sidebarmenu.js"></script>
    <script src="<?= base_url() ?>assets/node_modules/sticky-kit-master/dist/sticky-kit.min.js"></script>
    <script src="<?= base_url() ?>assets/node_modules/sparkline/jquery.sparkline.min.js"></script>
    <script src="<?= base_url() ?>assets/dist/js/custom.min.js"></script>

    <script src="<?= base_url() ?>assets/node_modules/switchery/dist/switchery.min.js"></script>
    <script src="<?= base_url() ?>assets/node_modules/select2/dist/js/select2.full.min.js" type="text/javascript"></script>
    <script src="<?= base_url() ?>assets/node_modules/bootstrap-select/bootstrap-select.min.js" type="text/javascript"></script>
    <script src="<?= base_url() ?>assets/node_modules/bootstrap-tagsinput/dist/bootstrap-tagsinput.min.js"></script>
    <script src="<?= base_url() ?>assets/node_modules/bootstrap-touchspin/dist/jquery.bootstrap-touchspin.js" type="text/javascript"></script>
    <script src="<?= base_url() ?>assets/node_modules/dff/dff.js" type="text/javascript"></script>
    <script src="<?= base_url() ?>assets/node_modules/multiselect/js/jquery.multi-select.js" type="text/javascript"></script>
</body>

</html>
<script>
    $(document).ready(function() {
        $(window).keydown(function(event){
            if(event.keyCode == 13) {
                event.preventDefault();
                // return false;
            }
        });
    });
</script>