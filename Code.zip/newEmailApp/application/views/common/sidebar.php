<div class="col-lg-3 col-md-4" style="height:100vh !important;">
    <div class="card-body inbox-panel"><a href="<?= base_url('compose') ?>" class="btn btn-danger m-b-20 p-10 btn-block waves-effect waves-light">Compose</a>
        <ul class="list-group list-group-full">
            <li class="list-group-item <?= $this->uri->segment(1) == 'inbox' ? 'active' : '' ?>"> <a href="<?= base_url('inbox') ?>"><i class="mdi mdi-gmail"></i> Inbox </a></li>
            <li class="list-group-item <?= $this->uri->segment(1) == 'sent' ? 'active' : '' ?>">
                <a href="<?= base_url('sent') ?>"> <i class="mdi mdi-file-document-box"></i> Sent </a>
            </li>
            <li class="list-group-item">
                <a href="<?= base_url() ?>account/logout"> <i class="mdi mdi-logout"></i> Logout </a>
            </li>
            <br>
            <li class="list-group-item">Name : <?= $this->user->name ? $this->user->name : 'Anonymous'; ?><br>Email &nbsp;: <?= $this->user->email; ?></li>
        </ul>
    </div>
</div>