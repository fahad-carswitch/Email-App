<?php
class Mail_to_model extends CI_Model
{
	private $table = "mail_to";

    public function insert_record($data)
    {
        $this->db->insert($this->table,$data);
        return $this->db->insert_id();
    }
    public function insert_batch_record($data)
    {
        $this->db->insert_batch($this->table,$data);
        return $this->db->insert_id();
    }

    public function get_record($whereConditionArray = null)
    {
        if ($whereConditionArray)
            $this->db->where($whereConditionArray);
        $query = $this->db->get($this->table);
        return $query->row();
    }

    public function get_records($whereConditionArray = null)
    {
        if ($whereConditionArray)
            $this->db->where($whereConditionArray);
        $query = $this->db->get($this->table);
        return $query->result();
    }

    public function update_record($whereConditionArray, $updateData)
    {
        $this->db->where($whereConditionArray);
        $query = $this->db->update($this->table, $updateData);
        if ($query)
            return true;
        else
            return false;
    }

    public function get_inbox_mails($email)
    {
        $this->db->select('mails.*,users.id as authorId,users.name as authorName,users.email as authorEmail');
        $this->db->where('mail_to.email', $email);
        $this->db->group_start();
            $this->db->or_where('mail_to.type', 'to');
            $this->db->or_where('mail_to.type', 'cc');
        $this->db->group_end();
        $this->db->join('mails','mails.id = mail_to.mail_id');
        $this->db->join('users','users.id = mails.author_id');
        $this->db->order_by('mails.id','desc');
        // $this->db->group_by('mail_to.mail_id');
        $query = $this->db->get($this->table);
        return $query->result();
    }

    public function get_mail_to_emails($mail_id)
    {
        $this->db->select('GROUP_CONCAT(email) emails_to');
        $this->db->where(['mail_id'=>$mail_id,'type'=>'to']);
        $query = $this->db->get($this->table);
        return $query->row();   
    }

    public function get_mail_cc_emails($mail_id)
    {
        $this->db->select('GROUP_CONCAT(email) email_cc');
        $this->db->where(['mail_id'=>$mail_id,'type'=>'cc']);
        $query = $this->db->get($this->table);
        return $query->row();   
    }
}