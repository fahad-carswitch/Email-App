<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Login_model extends CI_Model
{
	private $table = "login";
	private $tableId = "loginId";

	public function insert_record($recordData)
	{
		$this->db->insert($this->table, $recordData);
		return $this->db->insert_id();
	}

	public function get_record($whereConditionArray = null, $orderBy = null)
	{
		if ($whereConditionArray)
			$this->db->where($whereConditionArray);
		$this->db->order_by($this->tableId, 'desc');
		$query = $this->db->get($this->table);
		return $query->row();
	}

	public function get_records($whereConditionArray = null, $select = '*')
	{
		if ($whereConditionArray)
			$this->db->where($whereConditionArray);
		$this->db->select($select);
		$this->db->order_by($this->tableId, 'desc');
		$query = $this->db->get($this->table);
		return $query->result();
	}

	public function update_record($whereConditionArray, $updateData)
	{
		$this->db->where($whereConditionArray);
		if ($this->db->update($this->table, $updateData))
			return true;
		else
			return false;
	}
}
