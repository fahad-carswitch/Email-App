<?php
class Mail_messages_model extends CI_Model
{
	private $table = "mail_messages";

    public function insert_record($data)
    {
        $this->db->insert($this->table,$data);
        return $this->db->insert_id();
    }
    public function insert_batch_record($data)
    {
        $this->db->insert_batch($this->table,$data);
        return $this->db->insert_id();
    }

    public function get_record($whereConditionArray = null,$order_by)
    {
        $this->db->select('mail_messages.*,users.id as senderId,users.name as senderName,users.email as senderEmail');
        if ($whereConditionArray)
            $this->db->where($whereConditionArray);
        $this->db->join('users','users.email=mail_messages.msg_from','left');
        if($order_by)
            $this->db->order_by('mail_messages.msg_id',$order_by);   
        $query = $this->db->get($this->table);
        return $query->row();
    }

    public function get_records($whereConditionArray = null,$order_by=null)
    {
        $this->db->select('mail_messages.*,users.id as senderId,users.name as senderName,users.email as senderEmail');
        if ($whereConditionArray)
            $this->db->where($whereConditionArray);
        $this->db->join('users','users.email=mail_messages.msg_from','left'); 
        if($order_by)
            $this->db->order_by('mail_messages.msg_id',$order_by); 
        $query = $this->db->get($this->table);
        return $query->result();
    }

    public function update_record($whereConditionArray, $updateData)
    {
        $this->db->where($whereConditionArray);
        $query = $this->db->update($this->table, $updateData);
        if ($query)
            return true;
        else
            return false;
    }

    public function get_sent_messages_mails($email)
    {
        $this->db->select('*');
        $this->db->where(['msg_from'=>$email]);
        // $this->db->join('users','users.email=mail_messages.msg_from','left'); 
        // $this->db->order_by('mail_messages.msg_id','desc');
        $this->db->group_by('mail_messages.mail_id'); 
        $query = $this->db->get($this->table);
        return $query->result();
    }
}