<?php
class Users_model extends CI_Model
{
	private $table = "users";

    public function insert_record($data)
    {
        $this->db->insert($this->table,$data);
        return $this->db->insert_id();
    }
    public function insert_batch_record($data)
    {
        $this->db->insert_batch($this->table,$data);
        return $this->db->insert_id();
    }

    public function get_record($whereConditionArray = null)
    {
        if ($whereConditionArray)
            $this->db->where($whereConditionArray);
        $query = $this->db->get($this->table);
        return $query->row();
    }

    public function get_records($whereConditionArray = null)
    {
        $this->db->where($this->isDeleted, 0);
        if ($whereConditionArray)
            $this->db->where($whereConditionArray);
        $query = $this->db->get($this->table);
        return $query->result();
    }

    public function update_record($whereConditionArray, $updateData)
    {
        $this->db->where($whereConditionArray);
        $query = $this->db->update($this->table, $updateData);
        if ($query)
            return true;
        else
            return false;
    }
}